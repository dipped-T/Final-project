<!DOCTYPE html>
<html lang="en-EN">
<head>
	<title><?php echo $page_title; //Displaying the page title ?></title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width,initial-scale=1">
	<link rel="stylesheet" type="text/css" href="<?php echo url_for('assets/css/style.css');//call the styling sheet CSS ?>">
</head>
